#include <iostream>
#include <fstream>
#include <ctime>
#include <cstdlib>
#include <cstring>
#include <ctype.h>

using namespace std;

void print(int);


int main(){
int opcion = 0;
int opcion2=0;
int opcion3=0;
int opcion4=0;
int random;
char cadena[128];
srand(time(0));
char facil[70][128];
char normal[70][128];
char dificil[70][128];
char einstein[70][128];
char kelvin[70][128];
char easy[70][128];
char normal2[70][128];
char hard[70][128];
char einstein2[70][128];
char kelvin2[70][128];
int cont=0;
int oportunidades=-1;
int controlador;
char comando;
char comando2[128];
int cont2=0;
int cont3=0;
int t;
char almacen[0][128];
int gano=0;
char almacen2[128];
char upper;
int cont4=0;
int cont5=0;
int cont6=0;
int cont7=0;
        cout<<"ATENCION! SOLO INGRESE LETRAS EN MAYUSCULAS AL JUGAR!"<<endl<<"ATTENTION! JUST USE CAPITAL LETTERS WHEN PLAYING!"<<endl;
	while (opcion<3){
	cout<<"Ingrese su idoma/Select your language"<<endl<<" 1)Español"<<endl<<" 2)English"<<endl<<" >=3) Salir"<<endl;
	cin>>opcion;
		if(opcion==1){
			opcion3=0;
			while(opcion2<6){
			cout<<"Seleccione su dificultad"<<endl<<" 1) Facil"<<endl<<" 2) Normal"<<endl<<" 3) Dificil"<<endl<<" 4)Einstein"<<endl<<" 5)Kelvin"<<endl<<" >=6)Salir"<<endl;
			cin>>opcion2;

			if(opcion2==1){
			cont6=0;
			cont7=0;
			cont=0;
			cout<<endl<<"Dificultad Facil"<<endl;
			ifstream fe("facil.txt");
			while(!fe.eof()){
			fe>>facil[cont];
				cont++;
						}//FIN LEER FACIL
				fe.close();

				oportunidades=-1;
				random=rand()%20;
			for(int i =0; i<20; i++){
                        if(i==random){
                     //cout<<facil[i]<<endl;
                        controlador=i;
                        break;
                                        }
                                }
                t=strlen(facil[controlador]);
                for (int i = 0; i<t;i++){
                        almacen[0][i]='_';
                        }


			while((oportunidades<8)&&(opcion4<3)&&(gano!=1)){
cout<<"Ingrese su opcion"<<endl<<" 1) Caracter"<<endl<<" 2) Palabra Completa"<<endl<<" >3) Salir"<<endl;
			cin>>opcion4;

		cont2=0;
		if(opcion4==1){
			cout<<"Ingrese su caracter"<<endl;
			cin>>comando;
			toupper(comando);
			//upper=putchar(toupper(comando));
                        //  upper= toupper(comando);
	cout<<endl;
			for (int i = 0; i<t;i++){
				if(comando==facil[controlador][i]){

				cont2++;
				almacen[0][i]=comando;	
						}
				}
				if(cont2<1){

				cout<<"Caracter Incorrecto"<<endl;
				oportunidades++;
			        almacen2[cont6]=comando;	
			          cont6++;		
					}	
				}//FIN IF OPCION 4 == 1	
		if(opcion4==2){

			cout<<"Ingrese su palabra"<<endl;
				cin>>comando2;
				if(strlen(comando2)>t){
	cout<<"Su palabra es mas larga que la que quiere adivinar"<<endl;

				}//FIN IF LENGHT
		for (int i = 0; i<t; i++){
		if(comando2[i]!=facil[controlador][i]){
				cout<<"SE EQUIVOCO!!"<<endl;
				cont3++;
				oportunidades++;	
				break;
					}//FIN IF 
				}//FIN FOR
			for(int i = 0; i <t; i++){
                                if(comando2[i]==facil[controlador][i]){
          				cont7++;                      
                                                
                                                }
                                                }
	
					
			}//FIN IF OPCION 4 == 2
				cout<<almacen[0]<<endl;
	cout<<"Sus errores"<<endl;	
		for (int i = 0; i<cont6;i++){
		cout<<almacen2[i]<<" ";
				}	
			print(oportunidades);	
				cont4=0;	
	for (int i = 0; i<t; i++){
			if(almacen[0][i]==facil[controlador][i]){
				cont4++;
					}
				}
				if(cont4==t||cont7==t){
				cout<<"FELICIDADES HAS GANADO!"<<endl;
				gano++;
}	
				}//FIN WHILE AHORCADO EN FACIL
gano=0;	
				}//Fin IF OPCION 2 ==1
				opcion4 = 0;

///////////////////////////////////////////////////////////////////////////////

			if(opcion2 == 2){
cont6=0;
			cont7=0;
			cont=0;
                        cout<<endl<<"Dificultad Normal"<<endl;
                        ifstream fe("normal1.txt");
                        while(!fe.eof()){
                        fe>>normal[cont];
                                cont++;
                                                }//FIN LEER NORMAL 
                                fe.close();
			oportunidades=-1;
				random=rand()%20;
			for(int i =0; i<20; i++){
                        if(i==random){
                     //cout<<normal[i]<<endl;
                        controlador=i;
                        break;
                                        }
                                }
                t=strlen(normal[controlador]);
                for (int i = 0; i<t;i++){
                        almacen[0][i]='_';
                        }


			while((oportunidades<8)&&(opcion4<3)&&(gano!=1)){
cout<<"Ingrese su opcion"<<endl<<" 1) Caracter"<<endl<<" 2) Palabra Completa"<<endl<<" >3) Salir"<<endl;
			cin>>opcion4;

		cont2=0;
		if(opcion4==1){
			cout<<"Ingrese su caracter"<<endl;
			cin>>comando;
			toupper(comando);
			//upper=putchar(toupper(comando));
                        //  upper= toupper(comando);
	cout<<endl;
			for (int i = 0; i<t;i++){
				if(comando==normal[controlador][i]){

				cont2++;
				almacen[0][i]=comando;	
						}
				}
				if(cont2<1){

				cout<<"Caracter Incorrecto"<<endl;
				oportunidades++;
almacen2[cont6]=comando;
                                  cont6++;

					}	
				}//FIN IF OPCION 4 == 1	
		if(opcion4==2){

			cout<<"Ingrese su palabra"<<endl;
				cin>>comando2;
				if(strlen(comando2)>t){
	cout<<"Su palabra es mas larga que la que quiere adivinar"<<endl;

				}//FIN IF LENGHT
		for (int i = 0; i<t; i++){
		if(comando2[i]!=normal[controlador][i]){
				cout<<"SE EQUIVOCO!!"<<endl;
				cont3++;
				oportunidades++;	
				break;
					}//FIN IF 
	
				}//FIN FOR
for(int i = 0; i <t; i++){
                                if(comando2[i]==normal[controlador][i]){
                                        cont7++;

                                                }
                                                }


			}//FIN IF OPCION 4 == 2
				cout<<almacen[0]<<endl;
cout<<"Sus errores"<<endl;     
                for (int i = 0; i<cont6;i++){
                cout<<almacen2[i]<<" ";
                                }
cout<<endl;  

		print(oportunidades);	
				cont4=0;	
	for (int i = 0; i<t; i++){
			if(almacen[0][i]==normal[controlador][i]){
				cont4++;
					}
				}
				if(cont4==t||cont7==t){
				cout<<"FELICIDADES HAS GANADO!"<<endl;
				gano++;
}	
				}//FIN WHILE AHORCADO EN normal
gano=0;	
				}//FIN IF OPCION2 == 2
opcion4 = 0;
///////////////////////////////////////////////////////////////////////////////

                        if(opcion2 == 3){
cont6=0;
			cont7=0;
                        cont=0;
                       cont5=0; 
			cout<<endl<<"Dificultad Dificil"<<endl;
                        ifstream fe("dificil.txt");
                        while(!fe.eof()){
                        fe.getline(dificil[cont], 128);
                                cont++;
                                                }//FIN LEER DIFICIL 
                                fe.close();
oportunidades=-1;
				random=rand()%16;
			for(int i =0; i<16; i++){
                        if(i==random){
                     //cout<<dificil[i]<<endl;
                        controlador=i;
                        break;
                                        }
                                }
                t=strlen(dificil[controlador]);
                for (int i = 0; i<t;i++){
                        almacen[0][i]='_';
                      if(dificil[controlador][i]==' '){
			almacen[0][i]=' ';
			cont5++;
					} 
			 }


			while((oportunidades<8)&&(opcion4<3)&&(gano!=1)){
cout<<"Ingrese su opcion"<<endl<<" 1) Caracter"<<endl<<" 2) Palabra Completa"<<endl<<" >3) Salir"<<endl;
			cin>>opcion4;

		cont2=0;
		if(opcion4==1){
			cout<<"Ingrese su caracter"<<endl;
			cin>>comando;
			toupper(comando);
			//upper=putchar(toupper(comando));
                        //  upper= toupper(comando);
	cout<<endl;
			for (int i = 0; i<t;i++){
				if(comando==dificil[controlador][i]){

				cont2++;
				almacen[0][i]=comando;	
						}
				}
				if(cont2<1){

				cout<<"Caracter Incorrecto"<<endl;
				oportunidades++;
almacen2[cont6]=comando;
                                  cont6++;

					}	
				}//FIN IF OPCION 4 == 1	
		if(opcion4==2){

			cout<<"Ingrese su palabra"<<endl;
				cin>>comando2;
				if(strlen(comando2)>t){
	cout<<"Su palabra es mas larga que la que quiere adivinar"<<endl;

				}//FIN IF LENGHT
		for (int i = 0; i<t; i++){
		if(comando2[i]!=dificil[controlador][i]){
				cout<<"SE EQUIVOCO!!"<<endl;
				cont3++;
				oportunidades++;	
				break;
					}//FIN IF 
	
				}//FIN FOR
				
for(int i = 0; i <t; i++){
                                if(comando2[i]==dificil[controlador][i]){
                                        cont7++;

                                                }
                                                }

			}//FIN IF OPCION 4 == 2
				cout<<almacen[0]<<endl;

cout<<"Sus errores"<<endl;     
                for (int i = 0; i<cont6;i++){
                cout<<almacen2[i]<<" ";
                                }
cout<<endl;  

		print(oportunidades);	
				cont4=0+cont5;	
	for (int i = 0; i<t; i++){
			if(almacen[0][i]==dificil[controlador][i]){
				cont4++;
					}
				}
				if(cont4==t-1||cont7==t-1){
				cout<<"FELICIDADES HAS GANADO!"<<endl;
				gano++;
}	
				}//FIN WHILE AHORCADO EN dificil
gano=0;

                                }//FIN IF OPCION2 == 3 

////////////////////////////////////////////////////////////////////////////////

                        if(opcion2 == 4){
			cont6=0;
			cont7=0;
			cont5=0;
                        cont=0;
                        cout<<endl<<"Dificultad Einstein"<<endl;
                        ifstream fe("einstein1.txt");
                        while(!fe.eof()){
			fe.getline(einstein[cont], 128);
                                cont++;
                                                }//FIN LEER EINSTEIN ESPAÑOL 
                                fe.close();

oportunidades=-1;
				random=rand()%20;
			for(int i =0; i<20; i++){
                        if(i==random){
                     //cout<<einstein[i]<<endl;
                        controlador=i;
                        break;
                                        }
                                }
                t=strlen(einstein[controlador]);
                for (int i = 0; i<t;i++){
                        almacen[0][i]='_';
                      if(einstein[controlador][i]==' '){
			almacen[0][i]=' ';
			cont5++;
					} 
			 }


			while((oportunidades<8)&&(opcion4<3)&&(gano!=1)){
cout<<"Ingrese su opcion"<<endl<<" 1) Caracter"<<endl<<" 2) Palabra Completa"<<endl<<" >3) Salir"<<endl;
			cin>>opcion4;

		cont2=0;
		if(opcion4==1){
			cout<<"Ingrese su caracter"<<endl;
			cin>>comando;
			toupper(comando);
			//upper=putchar(toupper(comando));
                        //  upper= toupper(comando);
	cout<<endl;
			for (int i = 0; i<t;i++){
				if(comando==einstein[controlador][i]){

				cont2++;
				almacen[0][i]=comando;	
						}
				}
				if(cont2<1){

				cout<<"Caracter Incorrecto"<<endl;
				oportunidades++;
almacen2[cont6]=comando;
                                  cont6++;

					}	
				}//FIN IF OPCION 4 == 1	
		if(opcion4==2){

			cout<<"Ingrese su palabra"<<endl;
				cin>>comando2;
				if(strlen(comando2)>t){
	cout<<"Su palabra es mas larga que la que quiere adivinar"<<endl;

				}//FIN IF LENGHT
		for (int i = 0; i<t; i++){
		if(comando2[i]!=einstein[controlador][i]){
				cout<<"SE EQUIVOCO!!"<<endl;
				cont3++;
				oportunidades++;	
				break;
					}//FIN IF 
	
				}//FIN FOR
				
for(int i = 0; i <t; i++){
                                if(comando2[i]==einstein[controlador][i]){
                                        cont7++;

                                                }
                                                }

			}//FIN IF OPCION 4 == 2
				cout<<almacen[0]<<endl;
cout<<"Sus errores"<<endl;     
                for (int i = 0; i<cont6;i++){
                cout<<almacen2[i]<<" ";
                                }
cout<<endl;  


		print(oportunidades);	
				cont4=0+cont5;	
	for (int i = 0; i<t; i++){
			if(almacen[0][i]==einstein[controlador][i]){
				cont4++;
					}
				}
				if(cont4==t-1||cont7==t-1){
				cout<<"FELICIDADES HAS GANADO!"<<endl;
				gano++;
}	
				}//FIN WHILE AHORCADO EN einstein
gano=0;


                                }//FIN IF OPCION2 == 4

////////////////////////////////////////////////////////////////////////////////

			if(opcion2 == 5){
			cont6=0;
			cont7=0;
                        cont=0;
			cont5=0;
                        cout<<endl<<"Dificultad Kelvin"<<endl;
                        ifstream fe("Kelvin.txt");
                        while(!fe.eof()){
			fe.getline(kelvin[cont], 128);
                                cont++;
                                                }//FIN LEER KELVIN ESPAÑOL
                                fe.close();

oportunidades=-1;
				random=rand()%30;
			for(int i =0; i<30; i++){
                        if(i==random){
                     //cout<<kelvin[i]<<endl;
                        controlador=i;
                        break;
                                        }
                                }
                t=strlen(kelvin[controlador]);
                for (int i = 0; i<t;i++){
                        almacen[0][i]='_';
                      if(kelvin[controlador][i]==' '){
			almacen[0][i]=' ';
			cont5++;
					} 
			 }


			while((oportunidades<8)&&(opcion4<3)&&(gano!=1)){
cout<<"Ingrese su opcion"<<endl<<" 1) Caracter"<<endl<<" 2) Palabra Completa"<<endl<<" >3) Salir"<<endl;
			cin>>opcion4;

		cont2=0;
		if(opcion4==1){
			cout<<"Ingrese su caracter"<<endl;
			cin>>comando;
			toupper(comando);
			//upper=putchar(toupper(comando));
                        //  upper= toupper(comando);
	cout<<endl;
			for (int i = 0; i<t;i++){
				if(comando==kelvin[controlador][i]){

				cont2++;
				almacen[0][i]=comando;	
						}
				}
				if(cont2<1){

				cout<<"Caracter Incorrecto"<<endl;
				oportunidades++;
almacen2[cont6]=comando;
                                  cont6++;

					}	
				}//FIN IF OPCION 4 == 1	
		if(opcion4==2){

			cout<<"Ingrese su palabra"<<endl;
				cin>>comando2;
				if(strlen(comando2)>t){
	cout<<"Su palabra es mas larga que la que quiere adivinar"<<endl;

				}//FIN IF LENGHT
		for (int i = 0; i<t; i++){
		if(comando2[i]!=kelvin[controlador][i]){
				cout<<"SE EQUIVOCO!!"<<endl;
				cont3++;
				oportunidades++;	
				break;
					}//FIN IF 
	
				}//FIN FOR
			for(int i = 0; i <t; i++){
                                if(comando2[i]==kelvin[controlador][i]){
                                        cont7++;

                                                }
                                                }

			}//FIN IF OPCION 4 == 2
				cout<<almacen[0]<<endl;
cout<<"Sus errores"<<endl;     
                for (int i = 0; i<cont6;i++){
                cout<<almacen2[i]<<" ";
                                }
cout<<endl;  

		print(oportunidades);	
				cont4=0+cont5;	
	for (int i = 0; i<t; i++){
			if(almacen[0][i]==kelvin[controlador][i]){
				cont4++;
					}
				}
				if(cont4==t-1||cont7==t-1){
				cout<<"FELICIDADES HAS GANADO!"<<endl;
				gano++;
}	
				}//FIN WHILE AHORCADO EN kelvin
gano=0;

                                }//FIN IF OPCION2 == 5 

////////////////////////////////////////////////////////////////////////////////

			}//fin while opcion2<6
		opcion=0;
		opcion2=0;
		opcion4=0;	
				}//FIN IF OPCION==1	

//-------------------------------------------------------------------------//

		if(opcion==2){
		
		opcion2=0;
while(opcion3<6){
			cout<<"Select your difficulty level "<<endl<<" 1) Easy"<<endl<<" 2) Normal"<<endl<<" 3) Hard"<<endl<<" 4)Einstein"<<endl<<" 5)Kelvin"<<endl<<" >=6)Salir"<<endl;
			cin>>opcion3;
			if(opcion3==1){
			cont6=0;
			cont7=0;
			cont=0;
			cout<<endl<<"Difficulty Easy"<<endl;
			ifstream fe("easy.txt");
			while(!fe.eof()){
			fe>>easy[cont];
				cont++;
						}//FIN LEER EASY 
				fe.close();
	
		oportunidades=-1;
				random=rand()%20;
			for(int i =0; i<20; i++){
                        if(i==random){
                     //cout<<easy[i]<<endl;
                        controlador=i;
                        break;
                                        }
                                }
                t=strlen(easy[controlador]);
                for (int i = 0; i<t;i++){
                        almacen[0][i]='_';
                        }


			while((oportunidades<8)&&(opcion4<3)&&(gano!=1)){
cout<<"choose your opcion"<<endl<<" 1) Caracter"<<endl<<" 2) complete word"<<endl<<" >3) exit"<<endl;
			cin>>opcion4;

		cont2=0;
		if(opcion4==1){
			cout<<"type your letter"<<endl;
			cin>>comando;
			toupper(comando);
			//upper=putchar(toupper(comando));
                        //  upper= toupper(comando);
	cout<<endl;
			for (int i = 0; i<t;i++){
				if(comando==easy[controlador][i]){

				cont2++;
				almacen[0][i]=comando;	
						}
				}
				if(cont2<1){

				cout<<"Try, Try Again!"<<endl;
				oportunidades++;
almacen2[cont6]=comando;
                                  cont6++;

					}	
				}//FIN IF OPCION 4 == 1	
		if(opcion4==2){

			cout<<"type your letterpalabra"<<endl;
				cin>>comando2;
				if(strlen(comando2)>t){
	cout<<"Your word is larger than existance itself!!"<<endl;

				}//FIN IF LENGHT
		for (int i = 0; i<t; i++){
		if(comando2[i]!=easy[controlador][i]){
				cout<<"WRONG!!!!"<<endl;
				cont3++;
				oportunidades++;	
				break;
					}//FIN IF 
	
				}//FIN FOR
				for(int i = 0; i <t; i++){
                                if(comando2[i]==easy[controlador][i]){
                                        cont7++;

                                                }
                                                }

					
			}//FIN IF OPCION 4 == 2
				cout<<almacen[0]<<endl;
cout<<"Sus errores"<<endl;     
                for (int i = 0; i<cont6;i++){
                cout<<almacen2[i]<<" ";
                                }
cout<<endl;  


		print(oportunidades);	
				cont4=0;	
	for (int i = 0; i<t; i++){
			if(almacen[0][i]==easy[controlador][i]){
				cont4++;
					}
				}
				if(cont4==t||cont7==t){
				cout<<"CONGRATULATIONS YOU WON!"<<endl;
				gano++;
}	
				}//FIN WHILE AHORCADO EN easy
gano=0;	
				
				}//Fin IF OPCION 3 ==1
opcion4 = 0;

///////////////////////////////////////////////////////////////////////////////

			if(opcion3 == 2){
			cont6=0;
			cont7=0;
			cont=0;
                        cout<<endl<<"Difficulty Normal"<<endl;
                        ifstream fe("normal.txt");
                        while(!fe.eof()){
                        fe>>normal2[cont];
                                cont++;
                                                }//FIN LEER NORMAL2 
                                fe.close();
			


		oportunidades=-1;
				random=rand()%20;
			for(int i =0; i<20; i++){
                        if(i==random){
                     //cout<<normal2[i]<<endl;
                        controlador=i;
                        break;
                                        }
                                }
                t=strlen(normal2[controlador]);
                for (int i = 0; i<t;i++){
                        almacen[0][i]='_';
                        }


			while((oportunidades<8)&&(opcion4<3)&&(gano!=1)){
cout<<"choose your opcion"<<endl<<" 1) Caracter"<<endl<<" 2) complete word"<<endl<<" >3) exit"<<endl;
			cin>>opcion4;

		cont2=0;
		if(opcion4==1){
			cout<<"type your letter"<<endl;
			cin>>comando;
			toupper(comando);
			//upper=putchar(toupper(comando));
                        //  upper= toupper(comando);
	cout<<endl;
			for (int i = 0; i<t;i++){
				if(comando==normal2[controlador][i]){

				cont2++;
				almacen[0][i]=comando;	
						}
				}
				if(cont2<1){

				cout<<"Try, Try Again!"<<endl;
				oportunidades++;
almacen2[cont6]=comando;
                                  cont6++;

					}	
				}//FIN IF OPCION 4 == 1	
		if(opcion4==2){

			cout<<"type your letterpalabra"<<endl;
				cin>>comando2;
				if(strlen(comando2)>t){
	cout<<"Your word is larger than existance itself!!"<<endl;

				}//FIN IF LENGHT
		for (int i = 0; i<t; i++){
		if(comando2[i]!=normal2[controlador][i]){
				cout<<"WRONG!!!!"<<endl;
				cont3++;
				oportunidades++;	
				break;
					}//FIN IF 
	
				}//FIN FOR
				
				for(int i = 0; i <t; i++){
                                if(comando2[i]==normal2[controlador][i]){
                                        cont7++;

                                                }
                                                }
				
	
			}//FIN IF OPCION 4 == 2
				cout<<almacen[0]<<endl;

cout<<"Sus errores"<<endl;     
                for (int i = 0; i<cont6;i++){
                cout<<almacen2[i]<<" ";
                                }
cout<<endl;  

		print(oportunidades);	
				cont4=0;	
	for (int i = 0; i<t; i++){
			if(almacen[0][i]==normal2[controlador][i]){
				cont4++;
					}
				}
				if(cont4==t||cont7==t){
				cout<<"CONGRATULATIONS YOU WON!"<<endl;
				gano++;
}	
				}//FIN WHILE AHORCADO EN normal2
gano=0;	


				}//FIN IF OPCION3 == 2
opcion4=0;

///////////////////////////////////////////////////////////////////////////////

                        if(opcion3 == 3){
			cont6=0;
			cont7=0;
                        cont=0;
			cont5=0;
                        cout<<endl<<"Difficulty Hard"<<endl;
                        ifstream fe("hard.txt");
                        while(!fe.eof()){
			fe.getline(hard[cont], 128);
                                cont++;
                                                }//FIN LEER HARD 
                                fe.close();

oportunidades=-1;
				random=rand()%15;
			for(int i =0; i<15; i++){
                        if(i==random){
                     //cout<<hard[i]<<endl;
                        controlador=i;
                        break;
                                        }
                                }
                t=strlen(hard[controlador]);
                for (int i = 0; i<t;i++){
                        almacen[0][i]='_';
                      if(hard[controlador][i]==' '){
			almacen[0][i]=' ';
			cont5++;
					} 
			 }


			while((oportunidades<8)&&(  opcion4<3)&&(gano!=1)){
cout<<"Type your  opcion"<<endl<<" 1) Caracter"<<endl<<" 2) complete word"<<endl<<" >3) exit"<<endl;
			cin>>  opcion4;

		cont2=0;
		if(  opcion4==1){
			cout<<"Type yourcaracter"<<endl;
			cin>>comando;
			toupper(comando);
			//upper=putchar(toupper(comando));
                        //  upper= toupper(comando);
	cout<<endl;
			for (int i = 0; i<t;i++){
				if(comando==hard[controlador][i]){

				cont2++;
				almacen[0][i]=comando;	
						}
				}
				if(cont2<1){

				cout<<"Try, Try Again!"<<endl;
				oportunidades++;
almacen2[cont6]=comando;
                                  cont6++;

					}	
				}//FIN IF   opcion 4 == 1	
		if(  opcion4==2){

			cout<<"Type yourword"<<endl;
				cin>>comando2;
				if(strlen(comando2)>t){
	cout<<"Your word is larger than existance itself!!"<<endl;

				}//FIN IF LENGHT
		for (int i = 0; i<t; i++){
		if(comando2[i]!=hard[controlador][i]){
				cout<<"WRONG!!"<<endl;
				cont3++;
				oportunidades++;	
				break;
					}//FIN IF 
	
				}//FIN FOR
				
				for(int i = 0; i <t; i++){
                                if(comando2[i]==hard[controlador][i]){
                                        cont7++;

                                                }
                                                }

					
			}//FIN IF   opcion 4 == 2
				cout<<almacen[0]<<endl;

cout<<"Sus errores"<<endl;     
                for (int i = 0; i<cont6;i++){
                cout<<almacen2[i]<<" ";
                                }
cout<<endl;  

		print(oportunidades);	
				cont4=0+cont5;	
	for (int i = 0; i<t; i++){
			if(almacen[0][i]==hard[controlador][i]){
				cont4++;
					}
				}
				if(cont4==t-1||cont7==t-1){
				cout<<"CONGRATULATIONS YOU WON!"<<endl;
				gano++;
}	
				}//FIN WHILE AHORCADO EN hard
gano=0;


                                }//FIN IF OPCION3 == 3 
opcion4=0;
////////////////////////////////////////////////////////////////////////////////

                        if(opcion3 == 4){
			cont6=0;
			cont7=0;
                        cont=0;
			cont5=0;
                        cout<<endl<<"Difficulty Einstein"<<endl;
                        ifstream fe("einstein.txt");
                        while(!fe.eof()){
                        fe.getline(einstein2[cont], 128);
                                cont++;
                                                }//FIN LEER EINSTEIN INGLES 
                                fe.close();

oportunidades=-1;
				random=rand()%20;
			for(int i =0; i<20; i++){
                        if(i==random){
                     //cout<<einstein2[i]<<endl;
                        controlador=i;
                        break;
                                        }
                               }
                t=strlen(einstein2[controlador]);
                for (int i = 0; i<t;i++){
                        almacen[0][i]='_';
                      if(einstein2[controlador][i]==' '){
			almacen[0][i]=' ';
			cont5++;
					} 
			 }


			while((oportunidades<8)&&(  opcion4<3)&&(gano!=1)){
cout<<"Type your  opcion"<<endl<<" 1) Caracter"<<endl<<" 2) complete word"<<endl<<" >3) exit"<<endl;
			cin>>  opcion4;

		cont2=0;
		if(  opcion4==1){
			cout<<"Type yourcaracter"<<endl;
			cin>>comando;
			toupper(comando);
			//upper=putchar(toupper(comando));
                        //  upper= toupper(comando);
	cout<<endl;
			for (int i = 0; i<t;i++){
				if(comando==einstein2[controlador][i]){

				cont2++;
				almacen[0][i]=comando;	
						}
				}
				if(cont2<1){

				cout<<"Try, Try Again!"<<endl;
				oportunidades++;
						almacen2[cont6]=comando;
                                  cont6++;
				}	
				}//FIN IF   opcion 4 == 1	
		if(  opcion4==2){

			cout<<"Type yourword"<<endl;
				cin>>comando2;
				if(strlen(comando2)>t){
	cout<<"Your word is larger than existance itself!!"<<endl;

				}//FIN IF LENGHT
		for (int i = 0; i<t; i++){
		if(comando2[i]!=einstein2[controlador][i]){
				cout<<"WRONG!!"<<endl;
				cont3++;
				oportunidades++;	
				break;
					}//FIN IF 
	
				}//FIN FOR
				
				for(int i = 0; i <t; i++){
                                if(comando2[i]==einstein2[controlador][i]){
                                        cont7++;

                                                }
                                                }

					
			}//FIN IF   opcion 4 == 2
				cout<<almacen[0]<<endl;
cout<<"Sus errores"<<endl;     
                for (int i = 0; i<cont6;i++){
                cout<<almacen2[i]<<" ";
                                }
cout<<endl;  


		print(oportunidades);	
				cont4=0+cont5;	
	for (int i = 0; i<t; i++){
			if(almacen[0][i]==einstein2[controlador][i]){
				cont4++;
					}
				}
				if(cont4==t-1||cont7==t-1){
				cout<<"CONGRATULATIONS YOU WON!"<<endl;
				gano++;
}	
				}//FIN WHILE AHORCADO EN einstein2
gano=0;

                                }//FIN IF OPCION3 == 4
opcion4=0;
////////////////////////////////////////////////////////////////////////////////

			if(opcion3 == 5){
			cont6=0;
			cont7=0;
                        cont=0;
			cont5=0;
                        cout<<endl<<"Difficulty Kelvin"<<endl;
                        ifstream fe("Kelvin2.txt");
                        while(!fe.eof()){
                        fe.getline(kelvin2[cont], 128);
                                cont++;
                                                }//FIN LEER KELVIN INGLES 
                                fe.close();

oportunidades=-1;
				random=rand()%36;
			for(int i =0; i<36; i++){
                        if(i==random){
                     //cout<<kelvin2[i]<<endl;
                        controlador=i;
                        break;
                                        }
                               }
                t=strlen(kelvin2[controlador]);
                for (int i = 0; i<t;i++){
                        almacen[0][i]='_';
                      if(kelvin2[controlador][i]==' '){
			almacen[0][i]=' ';
			cont5++;
					} 
			 }


			while((oportunidades<8)&&(  opcion4<3)&&(gano!=1)){
cout<<"Type your  opcion"<<endl<<" 1) Caracter"<<endl<<" 2) complete word"<<endl<<" >3) exit"<<endl;
			cin>>  opcion4;

		cont2=0;
		if(  opcion4==1){
			cout<<"Type yourcaracter"<<endl;
			cin>>comando;
			toupper(comando);
			//upper=putchar(toupper(comando));
                        //  upper= toupper(comando);
	cout<<endl;
			for (int i = 0; i<t;i++){
				if(comando==kelvin2[controlador][i]){

				cont2++;
				almacen[0][i]=comando;	
						}
				}
				if(cont2<1){

				cout<<"Caracter Incorrecto"<<endl;
				oportunidades++;

almacen2[cont6]=comando;
                                  cont6++;

					}	
				}//FIN IF   opcion 4 == 1	
		if(  opcion4==2){

			cout<<"Type yourword"<<endl;
				cin>>comando2;
				if(strlen(comando2)>t){
	cout<<"Your word is larger than existance itself!!"<<endl;

				}//FIN IF LENGHT
		for (int i = 0; i<t; i++){
		if(comando2[i]!=kelvin2[controlador][i]){
				cout<<"WRONG!!"<<endl;
				cont3++;
				oportunidades++;	
				break;
					}//FIN IF 
	
				}//FIN FOR
				
				for(int i = 0; i <t; i++){
                                if(comando2[i]==kelvin2[controlador][i]){
                                        cont7++;

                                                }
                                                }

					
			}//FIN IF   opcion 4 == 2
				cout<<almacen[0]<<endl;
cout<<"Sus errores"<<endl;     
                for (int i = 0; i<cont6;i++){
                cout<<almacen2[i]<<" ";
                                }
cout<<endl;  


		print(oportunidades);	
				cont4=0+cont5;	
	for (int i = 0; i<t; i++){
			if(almacen[0][i]==kelvin2[controlador][i]){
				cont4++;
					}
				}
				if(cont4==t-1||cont7==t-1){
				cout<<"CONGRATULATIONS YOU WON!"<<endl;
				gano++;
}	
				}//FIN WHILE AHORCADO EN kelvin2
gano=0;

                                }//FIN IF OPCION3 == 5 
opcion4=0;
////////////////////////////////////////////////////////////////////////////////

			}//fin while opcion3<6
		opcion3=0;
		opcion=0;
		opcion4=0;	
			}//FIN IF OPCION == 2 

//-------------------------------------------------------------------------//

	}//FIN WHILE IDIOMA
return 0;
}//FIN	MAIN

/////XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX///

void print(int oportunidades){
if(oportunidades==0){
cout<<"|-----|"<<endl<<"|      "<<endl<<"|     "<<endl<<"|     "<<endl<<"|"<<endl<<"|"<<endl;

		}

if(oportunidades==1){
cout<<"|-----|"<<endl<<"|     o"<<endl<<"|     "<<endl<<"|     "<<endl<<"|"<<endl<<"|"<<endl;
		}
if(oportunidades==2){
cout<<"|-----|"<<endl<<"|     o"<<endl<<"|     |"<<endl<<"|     "<<endl<<"|"<<endl<<"|"<<endl;

		}
if(oportunidades==3){
cout<<"|-----|"<<endl<<"|     o"<<endl<<"|    /|"<<endl<<"|     "<<endl<<"|"<<endl<<"|"<<endl;

}
if(oportunidades==4){
cout<<"|-----|"<<endl<<"|     o"<<endl<<"|    /|\\"<<endl<<"|     "<<endl<<"|"<<endl<<"|"<<endl;

}
if (oportunidades==5){
cout<<"|-----|"<<endl<<"|     o"<<endl<<"|    /|\\"<<endl<<"|     |"<<endl<<"|"<<endl<<"|"<<endl;

}
if (oportunidades==6){
cout<<"|-----|"<<endl<<"|     o"<<endl<<"|    /|\\"<<endl<<"|    /|"<<endl<<"|"<<endl<<"|"<<endl;

}
if(oportunidades==7){
cout<<"|-----|"<<endl<<"|     o"<<endl<<"|    /|\\"<<endl<<"|    /|\\"<<endl<<"|"<<endl<<"|"<<endl;

}
} 
